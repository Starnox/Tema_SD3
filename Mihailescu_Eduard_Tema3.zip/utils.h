#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIGMA 68
#define ALPHABET "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-'?! "
#define MAX_BOOK 55
#define MAX_AUTHOR 45

#ifndef UTILS_H
#define UTILS_H

int GetIndexInAlphabet(char c);




#endif